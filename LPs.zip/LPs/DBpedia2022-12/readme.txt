We generated learning problems by following the steps below:

0. Fix a random seed for reproducibility. In Python, this can be done with `random.seed(42) np.random.seed(42)`

1. Preselect some atomic concepts in DBpedia: Journalist, HistoricPlace, Lipid, Profession, Model, President, Academic, Actor, Place, FootballMatch

2. In a loop with 200 steps do:
   a.) Randomly select two atomic concepts (C, D) from the above list to form a class expression of the form `C \sqcup D` with probability 0.5 and `C \sqcap D` with probability 0.5

    b.) With probability 0.1, negate the expression from step a.). Note that the expression stays unchanged with probability 0.9.

    c.) With probability 0.2, do:
        i.) Randomly and uniformly choose an object property in DBpedia. The list of all object properties is obtain in Ontolearn as `list(kb.ontology.object_properties_in_signature())`
        ii.) Randomly and uniformly choose a quantifier from ['∃', '∀'] to form the final expression. Assuming the expression from Step .b) is `Expr`, then the output expression from the current step (if executed) is of the form `∃ obj_prop.Expr` or `∀ obj_prop.Expr`
        
3. Convert the expression from Step c.) to a sparql query to be sent to the SPARQL endpoint "https://dbpedia.data.dice-research.org/sparql" in order to retrieve the set of instances of the expression. Here, we keep 100 instances by adding "\nLIMIT 100" to the SPARQL query

4. Negate the expression, convert the result to a SPARQL query, send the query to the endpoint to retrieve 100 individuals that are not instances of the expression (i.e., negative examples).

5. If the expression does not have any instances in the SPARQL endpoint or there are no negative examples, then we skeep the current expression and do not add it to our set of learning problems. 
